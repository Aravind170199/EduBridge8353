package exe1;
import java.util.Scanner;
public class youngAge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the age of ram :");
		int ramAge=scanner.nextInt();
		System.out.println("Enter the sulabh age :");
		int sulabhAge=scanner.nextInt();
		System.out.println("Enter the age of ajay :");
		int ajayAge=scanner.nextInt();
		
		if((ramAge<sulabhAge)&&(ramAge<ajayAge))
		{
			System.out.println("ram is young");
		}
		else if ((sulabhAge<ramAge)&&(sulabhAge<ajayAge))
		{
			System.out.println("sulabh is young");
		}
		else
		{
			System.out.println("ajay is young");
		}
	}

}
