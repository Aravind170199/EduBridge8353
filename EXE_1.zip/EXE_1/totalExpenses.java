package exe1;
import java.util.Scanner;
public class totalExpenses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float amt;
		double dis;
		double ta;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the amount of item ");
		
		amt=scanner.nextFloat();
		
		System.out.println("amount is "+amt);
		if (amt>5000)
		{
			System.out.println("eligible for 10% discount ");
			dis=amt*0.1;
			ta=amt-dis;
			System.out.println("your total amount is : "+ta);
		}
		else
		{
			System.out.println("you do not get any discount");
		}
		

	}

}
