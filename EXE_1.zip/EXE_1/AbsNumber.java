package exe1;
import java.util.Scanner;
public class AbsNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in); 
		  System.out.print("Enter number: ");
		  int number = scanner.nextInt();//local Variable
		  if(number<0)
		  System.out.println("Absolute numeric of given number '"+number+"': "+(-(number)));

	}

}